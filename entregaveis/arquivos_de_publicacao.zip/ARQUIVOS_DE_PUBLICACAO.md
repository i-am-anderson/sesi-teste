# Arquivos de publicação

Relação dos arquivos usados para publicar o SESI Indústria — Plataforma de Cursos e instruções para executá-la localmente caso a hospedagem esteja indisponível.

## Sumário

1. [Plataforma de hospedagem](#1-plataforma-de-hospedagem)
2. [Pacote ZIP de publicação](#2-pacote-zip-de-publicação)
3. [Arquivos do front-end](#3-arquivos-do-front-end)
4. [Arquivos da API](#4-arquivos-da-api)
5. [Banco de dados](#5-banco-de-dados)
6. [Variáveis de ambiente](#6-variáveis-de-ambiente)
7. [Execução local (hospedagem indisponível)](#7-execução-local-hospedagem-indisponível)

## 1. Plataforma de hospedagem

A aplicação está publicada no **Railway**, sem contratação de serviço pago: Trial Plan.

| Parte | Serviço | URL |
|---|---|---|
| Front-end | `client` | https://client-production-4d57.up.railway.app/ |
| API | `server` | https://server-production-49c8.up.railway.app/health |
| Banco de dados | `Postgres` (com volume) | Rede interna do projeto |

> A indisponibilidade temporária da hospedagem não impede a avaliação: a seção [7](#7-execução-local-hospedagem-indisponível) permite executar tudo localmente.

O Railway detecta cada projeto automaticamente a partir do repositório (diretórios `client/` e `server/`); **não há Dockerfile** nem arquivo de configuração do Railway. A configuração é feita apenas por variáveis de ambiente.

## 2. Pacote ZIP de publicação

O ZIP reúne o que é necessário para publicar ou executar a aplicação sem depender do build do Railway.

```
publicacao.zip
├── client/        Front-end já compilado (conteúdo de dist/)
├── server/        API compilada (saída de dotnet publish)
├── database/      Script SQL do banco (schema + dados iniciais)
├── README.md
└── ARQUIVOS_DE_PUBLICACAO.md
```

Como gerar cada parte:

```bash
# Front-end
cd client
VITE_API_URL=https://<url-da-api> yarn build      # gera client/dist/

# API
cd server
dotnet publish -c Release -o publish              # gera server/publish/

# Script SQL do banco 
dotnet ef migrations script --idempotent -o database.sql
```

## 3. Arquivos do front-end

| Arquivo / pasta | Função na publicação |
|---|---|
| `package.json` e `yarn.lock` | Dependências e scripts (`yarn build`) |
| `vite.config.ts` | Configuração do build (Vite) |
| `index.html` | Documento base da SPA |
| `src/` | Código-fonte |
| `.env` | Define `VITE_API_URL` (lido **em tempo de build**) |
| `dist/` | Resultado do build: site estático publicado |

**Fallback de SPA:** o app usa `BrowserRouter`, então o servidor estático deve devolver `index.html` para qualquer rota (ex.: `/curso/algebra-linear-aplicada` não pode dar 404 ao recarregar).

## 4. Arquivos da API

| Arquivo / pasta | Função na publicação |
|---|---|
| `SesiTeste.csproj` | Projeto .NET 10 (restore, build e publish) |
| `Program.cs` | Configuração da aplicação, CORS e aplicação de migrations/seed na inicialização |
| `appsettings.json` | Configuração base |
| `appsettings.Development.json` | Configuração local (conexão com o Postgres do `docker-compose.yml`) |
| `Migrations/` | Migrations do EF Core (criam o schema) |
| `Modules/` e `Shared/` | Código-fonte da API |
| `docker-compose.yml` | Postgres para execução local |
| `publish/` | Resultado do `dotnet publish` |

## 5. Banco de dados

- PostgreSQL. No Railway, serviço `Postgres` com volume para persistir os dados.
- O schema é criado pelas **migrations** e os cursos são populados por **seed**, ambos executados automaticamente na primeira inicialização da API.
- A migration `AddCourseSlug` apaga os cursos existentes antes de criar o índice único do slug; faça backup em bancos com dados reais.

## 6. Variáveis de ambiente

**API (`server`)**

| Variável | Valor |
|---|---|
| `ASPNETCORE_ENVIRONMENT` | `Production` |
| `ConnectionStrings__Default` | String de conexão do Postgres (formato Npgsql) |
| `Cors__AllowedOrigins__0` | `https://client-production-4d57.up.railway.app` |

No Railway, a string de conexão é montada com as variáveis do serviço Postgres:

```
Host=${{Postgres.PGHOST}};Port=${{Postgres.PGPORT}};Database=${{Postgres.PGDATABASE}};Username=${{Postgres.PGUSER}};Password=${{Postgres.PGPASSWORD}}
```

**Front-end (`client`)**

| Variável | Valor |
|---|---|
| `VITE_API_URL` | URL pública da API (definida **antes do build**) |

## 7. Execução local (hospedagem indisponível)

**Pré-requisitos:** Node.js 20.19.0+ e Yarn, .NET 10 SDK, Docker.

```bash
# 1. Banco de dados
cd server
docker compose up -d

# 2. API (aplica as migrations e popula os cursos ao iniciar)
dotnet run

# 3. Front-end (em outro terminal)
cd client
yarn
yarn dev
```

| Serviço | URL |
|---|---|
| Front-end | `http://localhost:5173` |
| API | `http://localhost:5116` |
| Health check | `http://localhost:5116/health` |

O front lê a API em `client/.env`:

```
VITE_API_URL=http://localhost:5116
```

**Acesso à área do aluno:** em `/login` entram qualquer e-mail e senha.

Mais detalhes (endpoints, modelo de dados, acessibilidade) estão no [README.md](README.md).